package com.hitherejoe.vineyard.data;

public class BusEvent {
    public static class AutoLoopUpdated { };
}
